import React, { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
export default function Student (props) {
    const [like, setLike] = useState(0)
    const handle = ()=>{
        setLike(like+1)
        console.log(like)
    }
  return (
    <>
        <div className="container">
      <div className="card w-50">
        <img src={props.img} className="card-img-top" alt="Card Image" />
        <div className="card-body">
          <h5 className="card-title">Card Title</h5>
          <p className="card-text">This is a sample card with an image.</p>
          <span>{like}</span>
          <button className='btn btn-primary' onClick={handle}>LIKE</button>
        </div>
      </div>
    </div>
    </>
  )
}
