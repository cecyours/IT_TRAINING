import logo from './logo.svg';
import './App.css';
import Student from './components/Student';
import imgx from './components/imgs/iron.jpg'
function App() {
  return (
    <div className="App">
      <header className="App-header">
         <Student studentName="gk" marks="199" img={imgx}/>
         <Student studentName="gk" marks="199" img={imgx}/>
         <Student studentName="gk" marks="199" img={imgx}/>
         <Student studentName="gk" marks="199" img={imgx}/>
        
      </header>
    </div>
  );
}

export default App;
